import tkinter as tk
from tkinter import ttk, messagebox
import webbrowser
import time
import threading
import pyautogui
from urllib.parse import urlparse, parse_qs
import os
import requests
import json
import io

class RobloxRejoiner:
    def __init__(self):
        print("Starting RobloxRejoiner initialization...")
        
        # Show UWP setup instructions first
        self.show_uwp_setup_instructions()
        
        self.root = tk.Tk()
        self.root.title("Sol's rng rejoiner")
        self.root.geometry("650x650")
        self.root.configure(bg="#2b2b2b")
        print("Window created")
        
        # Variables
        self.private_server_link = tk.StringVar()
        self.trigger_words = tk.StringVar(value="GLITCHED, DREAMSPACE")
        self.webhook_url = tk.StringVar()
        self.is_running = False
        self.webhook_sent_this_session = False
        self.log_file_path = ""
        self.last_log_position = 0
        self.join_time = 0
        self.timeout_seconds = 30
        self.successfully_joined = False
        self.last_successful_join = 0
        print("Variables initialized")
        
        # Create notebook for tabs
        self.create_tabs()
        
        print("Full initialization completed")
    
    def show_uwp_setup_instructions(self):
        """Show instructions for setting up Roblox UWP mode"""
        try:
            # Create a temporary root for the message box
            temp_root = tk.Tk()
            temp_root.withdraw()  # Hide the temporary window
            
            instructions = """IMPORTANT: Roblox UWP Setup Instructions



How to Set Microsoft Roblox as a default app or uwp

1. Set Microsoft roblox to your default app 

Important Notes:
• You MUST use Microsoft Store version of Roblox (not desktop .exe)
• UWP mode allows this script to read log files properly
• If you don't see the Microsoft roblox then you don't have it installed


Having issues?
• Reset your pc if you can't open microsoft roblox 

Click OK to continue with the script setup..."""

            # Show the instructions
            result = messagebox.showinfo(
                "Microsoft Roblox Setting it as a Default App", 
                instructions
            )
            
            temp_root.destroy()  # Clean up temporary root
            
        except Exception as e:
            print(f"Error showing UWP instructions: {e}")
    
    def create_tabs(self):
        """Create the tabbed interface"""
        print("Creating tabs...")
        
        # Create notebook widget
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Main tab
        self.main_tab = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.main_tab, text="Dashboard")
        
        # Donate tab
        self.donate_tab = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.donate_tab, text="Donate")
        
        # Build main tab content
        self.create_main_content()
        
        # Build donate tab content
        self.create_donate_content()
        
        # Initialize other components
        self.find_log_file()
        
        print("Tabs created successfully")
    
    def create_main_content(self):
        """Create the main tab content"""
        print("Creating main tab content...")
        
        # Title
        title_label = tk.Label(self.main_tab, text="Sol's rng rejoiner", 
                              font=("Arial", 16, "bold"), fg="#ffffff", bg="#2b2b2b")
        title_label.pack(pady=10)
        
        # Build UI step by step
        self.create_input_fields()
        self.create_control_buttons()
        self.create_log_area()
        
        print("Main tab content created successfully")
    
    def create_donate_content(self):
        """Create the donate tab content"""
        print("Creating donate tab content...")
        
        # Main container for donate tab
        donate_container = tk.Frame(self.donate_tab, bg="#2b2b2b")
        donate_container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        title_label = tk.Label(donate_container, text=" Support the Project", 
                              font=("Arial", 18, "bold"), fg="#51cf66", bg="#2b2b2b")
        title_label.pack(pady=(0, 20))
        
        # Description
        desc_text = ("Thank you for using Sol's rng rejoiner. If this tool has been helpful,\n"
                    "consider supporting the development by purchasing a Robux gamepass.\n"
                    "Your support helps keep this project free and updated!")
        
        desc_label = tk.Label(donate_container, text=desc_text, 
                             font=("Arial", 11), fg="#ffffff", bg="#2b2b2b",
                             justify="center")
        desc_label.pack(pady=(0, 30))
        
        # Gamepass section
        gamepass_frame = tk.Frame(donate_container, bg="#3a3a3a", relief="raised", bd=2)
        gamepass_frame.pack(fill="x", pady=10)
        
        # Gamepass header
        gamepass_header = tk.Label(gamepass_frame, text="Robux Gamepasses", 
                                  font=("Arial", 14, "bold"), fg="#fab005", bg="#3a3a3a")
        gamepass_header.pack(pady=15)
        
        # Gamepass options
        gamepasses = [
            {"name": "Medium Support ", "price": "50 Robux", "id": "GAMEPASS_ID_2", "color": "#fab005"},
            {"name": "Large Support ", "price": "100 Robux", "id": "GAMEPASS_ID_3", "color": "#ff6b6b"}
        ]
        
        for i, gamepass in enumerate(gamepasses):
            gamepass_btn_frame = tk.Frame(gamepass_frame, bg="#3a3a3a")
            gamepass_btn_frame.pack(fill="x", padx=20, pady=5)
            
            # Create button with gamepass info
            btn_text = f"{gamepass['name']} - {gamepass['price']}"
            gamepass_btn = tk.Button(gamepass_btn_frame, text=btn_text,
                                   command=lambda gp=gamepass: self.open_gamepass(gp),
                                   bg=gamepass['color'], fg="white", 
                                   font=("Arial", 12, "bold"),
                                   width=40, height=2)
            gamepass_btn.pack(pady=2)
        
        # Instructions
        instructions_frame = tk.Frame(donate_container, bg="#2b2b2b")
        instructions_frame.pack(fill="x", pady=20)
        
        instructions_text = (" How to donate:\n"
                           "1. Click on any gamepass button above\n"
                           "2. You'll be redirected to the Roblox gamepass page\n"
                           "3. Purchase the gamepass to support the project\n\n"
                           "  All donations are greatly appreciated!")
        
        instructions_label = tk.Label(instructions_frame, text=instructions_text,
                                    font=("Arial", 10), fg="#adb5bd", bg="#2b2b2b",
                                    justify="left")
        instructions_label.pack(anchor="w")
        
        # Alternative support section
        alt_frame = tk.Frame(donate_container, bg="#2b2b2b")
        alt_frame.pack(fill="x", pady=(20, 0))
        
        alt_title = tk.Label(alt_frame, text=" I don't know what to put here", 
                            font=("Arial", 12, "bold"), fg="#4dabf7", bg="#2b2b2b")
        alt_title.pack(anchor="w")
        
        alt_text = ("• I hope this helped you get into a glitch or dreamspace biome\n")
        
        alt_label = tk.Label(alt_frame, text=alt_text,
                            font=("Arial", 10), fg="#adb5bd", bg="#2b2b2b",
                            justify="left")
        alt_label.pack(anchor="w", pady=(5, 0))
        
        # Footer
        footer_label = tk.Label(donate_container, 
                               text="Made with love for the Roblox community",
                               font=("Arial", 10, "italic"), fg="#868e96", bg="#2b2b2b")
        footer_label.pack(side="bottom", pady=(30, 0))
        
        print("Donate tab content created successfully")
    
    def open_gamepass(self, gamepass):
        """Open the gamepass purchase page"""
        try:
            # Your actual Roblox gamepass URLs
            gamepass_urls = {
                "GAMEPASS_ID_2": "https://www.roblox.com/game-pass/1417438226/medium-support-50-robux", 
                "GAMEPASS_ID_3": "https://www.roblox.com/game-pass/1419043586/large-support-100-robux"
            }
            
            gamepass_id = gamepass["id"]
            if gamepass_id in gamepass_urls:
                webbrowser.open(gamepass_urls[gamepass_id])
            else:
                messagebox.showwarning("Coming Soon", 
                                      f"The {gamepass['name']} gamepass will be available soon!\n"
                                      f"Please check back later.")
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open gamepass page: {str(e)}")
    
    def create_input_fields(self):
        print("Creating input fields...")
        
        # Main container
        main_frame = tk.Frame(self.main_tab, bg="#2b2b2b")
        main_frame.pack(padx=20, pady=5, fill="both", expand=True)
        
        # Private server link
        link_frame = tk.Frame(main_frame, bg="#2b2b2b")
        link_frame.pack(fill="x", pady=5)
        
        tk.Label(link_frame, text="Private Server Link:", 
                fg="#ffffff", bg="#2b2b2b").pack(anchor="w")
        
        self.link_entry = tk.Entry(link_frame, textvariable=self.private_server_link, 
                                  font=("Arial", 10))
        self.link_entry.pack(fill="x", pady=2)
        
        # Trigger words
        words_frame = tk.Frame(main_frame, bg="#2b2b2b")
        words_frame.pack(fill="x", pady=5)
        
        tk.Label(words_frame, text="Trigger Words (comma-separated):", 
                fg="#ffffff", bg="#2b2b2b").pack(anchor="w")
        
        self.words_entry = tk.Entry(words_frame, textvariable=self.trigger_words, 
                                   font=("Arial", 10))
        self.words_entry.pack(fill="x", pady=2)
        
        # Timeout setting
        timeout_frame = tk.Frame(main_frame, bg="#2b2b2b")
        timeout_frame.pack(fill="x", pady=5)
        
        tk.Label(timeout_frame, text="Rejoin timeout (seconds) - only if join fails:", 
                fg="#ffffff", bg="#2b2b2b").pack(anchor="w")
        
        self.timeout_var = tk.IntVar(value=30)
        self.timeout_spin = tk.Spinbox(timeout_frame, from_=15, to=120, 
                                      textvariable=self.timeout_var, width=10)
        self.timeout_spin.pack(anchor="w", pady=2)
        
        # Webhook URL
        webhook_frame = tk.Frame(main_frame, bg="#2b2b2b")
        webhook_frame.pack(fill="x", pady=5)
        
        tk.Label(webhook_frame, text="Discord Webhook URL (optional):", 
                fg="#ffffff", bg="#2b2b2b").pack(anchor="w")
        
        self.webhook_entry = tk.Entry(webhook_frame, textvariable=self.webhook_url, 
                                     font=("Arial", 10))
        self.webhook_entry.pack(fill="x", pady=2)
        
        # Status section
        status_frame = tk.Frame(main_frame, bg="#2b2b2b")
        status_frame.pack(fill="x", pady=10)
        
        tk.Label(status_frame, text="Status:", 
                fg="#ffffff", bg="#2b2b2b", font=("Arial", 12, "bold")).pack(anchor="w")
        
        # Log file status
        self.log_status = tk.Label(status_frame, text="Searching for log file...", 
                                  fg="#fab005", bg="#2b2b2b")
        self.log_status.pack(anchor="w", pady=2)
        
        # Join status
        self.join_status = tk.Label(status_frame, text="Not monitoring", 
                                   fg="#868e96", bg="#2b2b2b")
        self.join_status.pack(anchor="w", pady=2)
        
        self.main_frame = main_frame
        self.root.update()
        print("Input fields created successfully")
    
    def create_control_buttons(self):
        print("Creating control buttons...")
        
        control_frame = tk.Frame(self.main_frame, bg="#2b2b2b")
        control_frame.pack(fill="x", pady=10)
        
        self.start_btn = tk.Button(control_frame, text="Start Monitoring", 
                                  command=self.start_monitoring,
                                  bg="#51cf66", fg="white", font=("Arial", 12, "bold"),
                                  width=15)
        self.start_btn.pack(side="left", padx=5)
        
        self.stop_btn = tk.Button(control_frame, text="Stop Monitoring", 
                                 command=self.stop_monitoring,
                                 bg="#ff6b6b", fg="white", font=("Arial", 12, "bold"),
                                 width=15, state="disabled")
        self.stop_btn.pack(side="left", padx=5)
        
        self.webhook_test_btn = tk.Button(control_frame, text="Test Webhook", 
                                         command=self.test_webhook,
                                         bg="#845ef7", fg="white", font=("Arial", 12),
                                         width=15)
        self.webhook_test_btn.pack(side="left", padx=5)
        
        self.refresh_log_btn = tk.Button(control_frame, text="Refresh Log Path", 
                                        command=self.find_log_file,
                                        bg="#4dabf7", fg="white", font=("Arial", 12),
                                        width=15)
        self.refresh_log_btn.pack(side="left", padx=5)
        
        self.root.update()
        print("Control buttons created successfully")
    
    def create_log_area(self):
        print("Creating log area...")
        
        log_frame = tk.Frame(self.main_frame, bg="#2b2b2b")
        log_frame.pack(fill="both", expand=True, pady=10)
        
        tk.Label(log_frame, text="Status Log:", 
                fg="#ffffff", bg="#2b2b2b", font=("Arial", 12, "bold")).pack(anchor="w")
        
        # Text widget with scrollbar
        text_container = tk.Frame(log_frame, bg="#2b2b2b")
        text_container.pack(fill="both", expand=True, pady=2)
        
        self.log_text = tk.Text(text_container, height=10, bg="#1e1e1e", fg="#ffffff",
                               font=("Consolas", 9), wrap=tk.WORD)
        
        scrollbar = tk.Scrollbar(text_container, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        self.root.update()
        print("Log area created successfully")
        
        # Add initial message
        self.log("Application started successfully!")
        self.log("Monitoring Roblox UWP log file for trigger words.")
        self.log("Note: This version works with Microsoft Store Roblox only.")
        self.log("Check out the Donate tab to support development!")
    
    def log(self, message):
        """Add message to log"""
        try:
            timestamp = time.strftime("%H:%M:%S")
            log_message = f"[{timestamp}] {message}\n"
            
            if hasattr(self, 'log_text') and self.log_text:
                self.log_text.insert(tk.END, log_message)
                self.log_text.see(tk.END)
                self.root.update_idletasks()
            else:
                print(f"LOG: {message}")
        except Exception as e:
            print(f"Logging error: {e}")
            print(f"Message was: {message}")
    
    def find_log_file(self):
        """Find the Roblox UWP log file"""
        try:
            username = os.getenv('USERNAME')
            
            # UWP Roblox log file locations
            possible_paths = [
                f"C:/Users/{username}/AppData/Local/Packages/ROBLOXCORPORATION.ROBLOX_55nm5eh3cm0pr/LocalState/logs",
                f"C:/Users/{username}/AppData/Local/Packages/ROBLOXCORPORATION.ROBLOX_55nm5eh3cm0pr/TempState/logs",
                f"C:/Users/{username}/AppData/Local/Packages/ROBLOXCORPORATION.ROBLOX_55nm5eh3cm0pr/AC/Temp/logs"
            ]
            
            # Also check for other possible UWP package names
            packages_dir = f"C:/Users/{username}/AppData/Local/Packages"
            if os.path.exists(packages_dir):
                for package in os.listdir(packages_dir):
                    if 'ROBLOX' in package.upper():
                        possible_paths.extend([
                            os.path.join(packages_dir, package, "LocalState", "logs"),
                            os.path.join(packages_dir, package, "TempState", "logs"),
                            os.path.join(packages_dir, package, "AC", "Temp", "logs")
                        ])
            
            # Also check standard locations as fallback
            possible_paths.extend([
                f"C:/Users/{username}/AppData/Local/Roblox/logs",
                f"C:/Users/{username}/AppData/Local/Temp/Roblox/logs"
            ])
            
            log_file = None
            found_dir = None
            
            for log_dir in possible_paths:
                if os.path.exists(log_dir):
                    self.log(f"Checking directory: {log_dir}")
                    
                    # Look for the most recent log file
                    log_files = []
                    try:
                        for file in os.listdir(log_dir):
                            if file.endswith('.log'):
                                file_path = os.path.join(log_dir, file)
                                log_files.append((file_path, os.path.getmtime(file_path)))
                        
                        if log_files:
                            # Get the most recent log file
                            log_file = max(log_files, key=lambda x: x[1])[0]
                            found_dir = log_dir
                            self.log(f"Found {len(log_files)} log files in directory")
                            break
                    except PermissionError:
                        self.log(f"Permission denied accessing {log_dir}")
                        continue
                    except Exception as e:
                        self.log(f"Error accessing {log_dir}: {str(e)}")
                        continue
            
            if log_file:
                self.log_file_path = log_file
                self.last_log_position = os.path.getsize(log_file) if os.path.exists(log_file) else 0
                self.log_status.config(text=f"Found: {os.path.basename(log_file)}", fg="#51cf66")
                self.log(f"Microsoft Roblox Log file found: {log_file}")
                self.log(f"Directory: {found_dir}")
                return True
            else:
                self.log_status.config(text="Microsoft Roblox log file not found", fg="#ff6b6b")
                self.log("Microsoft roblox log file not found. Make sure Roblox (Microsoft Store version) is running.")
                self.log("If you're using desktop Roblox, this tool is configured for Microsoft roblox version only.")
                return False
                
        except Exception as e:
            self.log(f"Microsoft Roblox Log file not found: {str(e)}")
            self.log_status.config(text="Microsoft Roblox log file not found", fg="#ff6b6b")
            return False
    
    def convert_to_roblox_url(self, private_server_link):
        """Convert private server link to roblox:// format"""
        try:
            parsed = urlparse(private_server_link)
            
            if '/games/' in private_server_link:
                parts = private_server_link.split('/games/')
                if len(parts) > 1:
                    place_id = parts[1].split('/')[0]
                    
                    query_params = dict(param.split('=') for param in parsed.query.split('&') if '=' in param)
                    if 'privateServerLinkCode' in query_params:
                        server_code = query_params['privateServerLinkCode']
                        roblox_url = f"roblox://placeId={place_id}&linkCode={server_code}"
                        return roblox_url
            
            self.log("Error: Invalid private server link format")
            return None
            
        except Exception as e:
            self.log(f"URL parsing error: {str(e)}")
            return None
    
    def join_server(self):
        """Join the Roblox private server"""
        if not self.private_server_link.get().strip():
            self.log("Error: No private server link provided")
            return False
        
        roblox_url = self.convert_to_roblox_url(self.private_server_link.get())
        if not roblox_url:
            return False
        
        try:
            webbrowser.open(roblox_url)
            self.log("Opening private server link...")
            
            # Reset webhook flag when joining new server
            self.webhook_sent_this_session = False
            
            # Record join attempt time
            self.join_time = time.time()
            self.successfully_joined = False
            
            # Update join status
            self.join_status.config(text="Joining server...", fg="#fab005")
            
            # Update log file position to current end
            if os.path.exists(self.log_file_path):
                self.last_log_position = os.path.getsize(self.log_file_path)
            
            return True
        except Exception as e:
            self.log(f"Error joining server: {str(e)}")
            self.join_status.config(text="Join failed", fg="#ff6b6b")
            return False
    
    def read_new_log_lines(self):
        """Read new lines from the log file since last read"""
        if not os.path.exists(self.log_file_path):
            return []
        
        try:
            current_size = os.path.getsize(self.log_file_path)
            
            # If file got smaller, it might have been recreated
            if current_size < self.last_log_position:
                self.last_log_position = 0
            
            # If no new content, return empty list
            if current_size <= self.last_log_position:
                return []
            
            # Read new content
            with open(self.log_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                f.seek(self.last_log_position)
                new_content = f.read()
                self.last_log_position = f.tell()
            
            # Split into lines and filter empty ones
            new_lines = [line.strip() for line in new_content.split('\n') if line.strip()]
            return new_lines
            
        except Exception as e:
            self.log(f"Error reading log file: {str(e)}")
            return []
    
    def check_join_success(self, lines):
        """Check if we've successfully joined the server based on log lines"""
        if not lines:
            return False
        
        # Look for indicators that we've successfully joined
        success_indicators = [
            "game joined",
            "connected to server",
            "player added",
            "spawn location",
            "character spawned",
            "workspace loaded"
        ]
        
        for line in lines:
            line_lower = line.lower()
            for indicator in success_indicators:
                if indicator in line_lower:
                    self.log(f"Join success detected: {indicator}")
                    return True
        
        return False
    
    def check_for_trigger_words(self, lines):
        """Check if any of the new log lines contain trigger words"""
        if not lines:
            return False, None
        
        trigger_words = [word.strip().lower() for word in self.trigger_words.get().split(',')]
        
        for line in lines:
            line_lower = line.lower()
            for word in trigger_words:
                if word and word in line_lower:
                    self.log(f"TRIGGER WORD FOUND: '{word}' in log line:")
                    self.log(f"   -> {line[:100]}...")
                    
                    # Send webhook notification with screenshot
                    if self.webhook_url.get().strip() and not self.webhook_sent_this_session:
                        self.send_webhook_notification(word, line)
                        self.webhook_sent_this_session = True
                        self.log("Webhook sent for this server session")
                    
                    return True, word
        
        return False, None
    
    def send_webhook_notification(self, trigger_word, log_line):
        """Send notification with screenshot to Discord webhook"""
        if not self.webhook_url.get().strip():
            return False
        
        try:
            # Take a screenshot of the entire screen
            screenshot = pyautogui.screenshot()
            
            # Convert screenshot to bytes
            img_buffer = io.BytesIO()
            screenshot.save(img_buffer, format='PNG')
            img_buffer.seek(0)
            
            # Check if trigger word is glitch or dreamspace for @everyone ping
            special_words = ['glitch', 'dreamspace', 'glitched']
            should_ping_everyone = trigger_word.lower() in special_words
            
            embed = {
                "title": "Found trigger word in Roblox log!",
                "color": 0x00ff00,
                "fields": [
                    {
                        "name": "Trigger Word",
                        "value": f"**{trigger_word}**",
                        "inline": True
                    },
                    {
                        "name": "Time",
                        "value": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "inline": True
                    },
                    {
                        "name": "Private Server Link",
                        "value": f"[Join Server]({self.private_server_link.get()})",
                        "inline": False
                    },
                    {
                        "name": "Log Line",
                        "value": f"```{log_line[:500]}...```" if len(log_line) > 500 else f"```{log_line}```",
                        "inline": False
                    }
                ],
                "footer": {
                    "text": "Please leave after the biome ends"
                },
                "image": {
                    "url": "attachment://screenshot.png"
                }
            }
            
            # Prepare the webhook payload with screenshot
            files = {
                'file': ('screenshot.png', img_buffer.getvalue(), 'image/png')
            }
            
            # Only ping @everyone for glitch, dreamspace, or glitched
            payload = {
                'embeds': [embed]
            }
            
            if should_ping_everyone:
                payload['content'] = '@everyone'
                self.log(f"Pinging @everyone for trigger word: {trigger_word}")
            else:
                self.log(f"No @everyone ping for trigger word: {trigger_word}")
            
            response = requests.post(
                self.webhook_url.get().strip(),
                data={'payload_json': json.dumps(payload)},
                files=files,
                timeout=10
            )
            
            if response.status_code == 204:
                self.log("Webhook with screenshot sent successfully!")
                return True
            else:
                self.log(f"Webhook failed with status: {response.status_code}")
                return False
                
        except Exception as e:
            self.log(f"Error sending webhook: {str(e)}")
            return False
    
    def test_webhook(self):
        """Test the Discord webhook"""
        if not self.webhook_url.get().strip():
            self.log("Please enter a Discord webhook URL first")
            return
        
        try:
            # Take a test screenshot
            screenshot = pyautogui.screenshot()
            success = self.send_webhook_notification("TEST", "This is a test message from the macro")
            if success:
                self.log("Test webhook with screenshot sent successfully!")
            else:
                self.log("Failed to send test webhook. Check the URL and try again.")
        except Exception as e:
            self.log(f"Webhook test error: {str(e)}")
    
    def monitoring_loop(self):
        """Main monitoring loop"""
        self.log("Starting log file monitoring...")
        
        while self.is_running:
            try:
                # Update timeout from UI
                self.timeout_seconds = self.timeout_var.get()
                
                # Read new log lines
                new_lines = self.read_new_log_lines()
                
                if new_lines:
                    self.log(f"Read {len(new_lines)} new log lines")
                    
                    # Check if we successfully joined (only if we haven't already confirmed)
                    if not self.successfully_joined and self.check_join_success(new_lines):
                        self.successfully_joined = True
                        self.last_successful_join = time.time()
                        self.join_status.config(text="Successfully joined server", fg="#51cf66")
                        self.log("Successfully joined server - monitoring for trigger words...")
                    
                    # Check for trigger words
                    found_trigger, trigger_word = self.check_for_trigger_words(new_lines)
                    
                    if found_trigger:
                        self.log(f"MONITORING STOPPED - Trigger word '{trigger_word}' found!")
                        self.log("Application will now stop monitoring.")
                        
                        # Stop monitoring
                        self.root.after(0, self.stop_monitoring_from_thread)
                        break
                
                # Only check timeout if we haven't successfully joined yet
                if not self.successfully_joined:
                    time_since_join = time.time() - self.join_time if self.join_time > 0 else 0
                    
                    if time_since_join >= self.timeout_seconds:
                        self.log(f"Join timeout reached ({self.timeout_seconds}s) - Attempting rejoin...")
                        self.join_server()
                        continue
                
                # Wait 100ms before next check
                time.sleep(0.1)
                
            except Exception as e:
                self.log(f"Monitoring error: {str(e)}")
                time.sleep(1)
        
        self.log("Monitoring loop ended.")
    
    def stop_monitoring_from_thread(self):
        """Stop monitoring when called from monitoring thread"""
        self.is_running = False
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.join_status.config(text="Monitoring stopped", fg="#868e96")
        self.log("Monitoring stopped automatically after finding trigger word.")
    
    def start_monitoring(self):
        """Start monitoring"""
        if not self.private_server_link.get().strip():
            messagebox.showwarning("Warning", "Please enter a private server link")
            return
        
        if not self.log_file_path or not os.path.exists(self.log_file_path):
            messagebox.showwarning("Warning", "Roblox UWP log file not found. Please start Roblox (Microsoft Store version) and click 'Refresh Log Path'")
            return
        
        self.is_running = True
        self.successfully_joined = False
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        
        self.log("Starting monitoring...")
        self.log("Monitoring will AUTOMATICALLY STOP when trigger words are found!")
        self.log(f"Will attempt rejoin if not successfully joined within {self.timeout_var.get()} seconds")
        
        # Join server immediately when starting
        self.join_server()
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(target=self.monitoring_loop, daemon=True)
        self.monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop monitoring"""
        self.is_running = False
        self.successfully_joined = False
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.join_status.config(text="Not monitoring", fg="#868e96")
        self.log("Monitoring stopped manually.")
    
    def run(self):
        """Run the application"""
        print("Starting GUI mainloop...")
        self.root.mainloop()
        print("Application closed")

if __name__ == "__main__":
    try:
        app = RobloxRejoiner()
        app.run()
    except Exception as e:
        print(f"Application error: {e}")
        import traceback
        traceback.print_exc()